MrDefMan

__Welcome__


This document contains some basic information for the use of DaggerfallPSC (Daggerfall Controls for PlayStation Classic Mini Console Controller)


__Requirements__


Playstation Classic Mini Console Controller (This is a replica Playstation 1 Controller designed for a licensed emulator, not an original PlayStation controller)

GlovePIE (Glove Programmable Input Emulator) Software required to run the script)


__Controls__


**DEGUB Mouse Speed**  --> Is your Mouse Cursor too slow or fast? <-- press L2 + R2 simultaneously to toggle the mouse speed from 1x to 3x or 3x to 1x)


Select (single press) - Jump

Select (hold)         - Run 

Select (double press) - Character Sheet / Log

D-Pad 		      - Mouse Cursor Movement

Triangle 	      - Move Forward

Square                - Move Left

X                     - Move Backwards

L1                    - Cast Spell

L2                    - Right Click (interact/select)

R1                    - Sheath/Unsheath Weapons

R2                    - Left Click (interact/pilfer/attack)



